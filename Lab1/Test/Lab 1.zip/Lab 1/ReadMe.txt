Please use the make file to compile the code.

The code uses three main files: lab1.cc, lab1.h and RandomForLab1.h

Group Members: Jung Tae Kim, Kshitij Mahendru