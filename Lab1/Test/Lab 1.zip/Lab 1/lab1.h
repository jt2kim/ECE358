#ifndef LAB_ONE
#define LAB_ONE
#include <queue>
#include <list>
#include <math.h>

void startSimulation(int ticks);
void arrival(double t);
void departure(double t);
void computePerformances();

#endif
